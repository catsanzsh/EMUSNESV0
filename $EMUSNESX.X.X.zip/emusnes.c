#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>

typedef struct {
    uint16_t pc;
    uint8_t reg[8];
    uint8_t s;
    uint8_t flags;
} CPU;

#define MEMORY_SIZE 0x1000000 // SNES memory size is 16MB
uint8_t memory[MEMORY_SIZE];

// Initialize the CPU state
void initCPU(CPU* cpu) {
    cpu->pc = 0x8000; // SNES starting point
    cpu->s = 0xFF;
    memset(cpu->reg, 0, sizeof(cpu->reg));
    cpu->flags = 0;
}

// Initialize memory
void initMemory() {
    memset(memory, 0, MEMORY_SIZE);
    // Load ROM, setup memory regions, etc.
}

// Load Times New Roman font from predefined paths
TTF_Font* loadTimesNewRomanFont(int fontSize) {
    const char* fontPaths[] = {
        "/Library/Fonts/Times New Roman.ttf",
        "/usr/share/fonts/truetype/msttcorefonts/Times_New_Roman.ttf",
        "/usr/share/fonts/TTF/times.ttf"
    };

    TTF_Font* font = NULL;
    for (size_t i = 0; i < sizeof(fontPaths) / sizeof(fontPaths[0]); i++) {
        font = TTF_OpenFont(fontPaths[i], fontSize);
        if (font) {
            printf("Loaded Times New Roman font from: %s\n", fontPaths[i]);
            return font;
        }
    }

    printf("Failed to load Times New Roman or any similar font.\n");
    return NULL;
}

// Main function
int main() {
    CPU cpu;
    initCPU(&cpu);
    initMemory();

    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        fprintf(stderr, "SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return 1;
    }

    if (TTF_Init() == -1) {
        fprintf(stderr, "SDL_ttf could not initialize! SDL_ttf Error: %s\n", TTF_GetError());
        SDL_Quit();
        return 1;
    }

    TTF_Font* font = loadTimesNewRomanFont(24);
    if (!font) {
        fprintf(stderr, "Failed to load any suitable font. SDL_ttf Error: %s\n", TTF_GetError());
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    SDL_Window* window = SDL_CreateWindow("iSNES",
                                          SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                                          600, 400,
                                          SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);

    if (!window) {
        fprintf(stderr, "Window could not be created! SDL_Error: %s\n", SDL_GetError());
        TTF_CloseFont(font);
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    SDL_SetWindowMinimumSize(window, 600, 400);
    SDL_SetWindowMaximumSize(window, 600, 400);

    int running = 1;
    while (running) {
        SDL_Event e;
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                running = 0; // Exit the loop if a quit event is received
            }
        }

        SDL_Surface* screenSurface = SDL_GetWindowSurface(window);
        SDL_FillRect(screenSurface, NULL, SDL_MapRGB(screenSurface->format, 0x00, 0x00, 0x00));
        SDL_UpdateWindowSurface(window);
    }

    TTF_CloseFont(font);
    SDL_DestroyWindow(window);
    TTF_Quit();
    SDL_Quit();

    return 0;
}
